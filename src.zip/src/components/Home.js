import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

const images = [
  {
    id: 1,
    src: 'https://picsum.photos/300/200?random=1',
    title: 'Imagem 1',
    description: 'Descrição'
  },
  {
    id: 2,
    src: 'https://picsum.photos/300/200?random=2',
    title: 'Imagem 2',
    description: 'Descrição'
  },
  {
    id: 3,
    src: 'https://picsum.photos/300/200?random=3',
    title: 'Imagem 3',
    description: 'Descrição'
  },
  {
    id: 4,
    src: 'https://picsum.photos/300/200?random=4',
    title: 'Imagem 4',
    description: 'Descrição'
  }
];

function Home() {
  const navigate = useNavigate();

  const handleImageClick = (imageId) => {
    navigate(`/detail/${imageId}`);
  };

  return (
    <div className="home">
      <h1>Galeria de Imagens</h1>
      <div className="image-grid">
        {images.map((image) => (
          <div 
            key={image.id} 
            className="image-card"
            onClick={() => handleImageClick(image.id)}
          >
            <img src={image.src} alt={image.title} />
            <h3>{image.title}</h3>
            <p>{image.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;