import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './Detail.css';

const images = [
  {
    id: 1,
    src: 'https://picsum.photos/600/400?random=1',
    title: 'Imagem 1',
    description: 'Descrição'
  },
  {
    id: 2,
    src: 'https://picsum.photos/600/400?random=2',
    title: 'Imagem 2',
    description: 'Descrição'
  },
  {
    id: 3,
    src: 'https://picsum.photos/600/400?random=3',
    title: 'Imagem 3',
    description: 'Descrição'
  },
  {
    id: 4,
    src: 'https://picsum.photos/600/400?random=4',
    title: 'Imagem 4',
    description: 'Descrição'
  }
];

function Detail() {
  const { imageId } = useParams();
  const navigate = useNavigate();
  const image = images.find(img => img.id === parseInt(imageId));

  if (!image) {
    return (
      <div className="detail">
        <h2>Imagem não encontrada</h2>
        <button onClick={() => navigate('/')}>Voltar</button>
      </div>
    );
  }

  return (
    <div className="detail">
      <button className="back-button" onClick={() => navigate('/')}>
        ← Voltar à Galeria
      </button>
      <div className="detail-content">
        <img src={image.src} alt={image.title} />
        <div className="detail-info">
          <h1>{image.title}</h1>
          <p>{image.description}</p>
        </div>
      </div>
    </div>
  );
}

export default Detail;